# Example collection

Collection to show that dependencies defined in role metadata does not work
